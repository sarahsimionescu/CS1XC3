/**
 * @file course.h
 * @author Sarah Simionescu
 * @date 04/02/2022
 * @brief Course library for managing and analyzing courses including their name, code and students.
 *        Includes Course type definition and course library function definitions.
 *
 */

#include "student.h"
#include <stdbool.h>

/**
 * Course type stores course details, including the course name, course code and a list of enrolled students.
 *
 */
typedef struct _course
{
  char name[100];     /**< the course name */
  char code[10];      /**< the course code */
  Student *students;  /**< student's enrolled in the course */
  int total_students; /**< the total number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course *course);
Student *passing(Course *course, int *total_passing);
