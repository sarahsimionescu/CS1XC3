/**
 * @file student.h
 * @author Sarah Simionescu
 * @date 04/02/2022
 * @brief Student library for managing, generating and analyzing student records including their name, id and grades.
 *        Includes Student type definition and student library function definitions.
 *
 */

/**
 * Student type stores a student's record and includes their first name, their last name, their 10-character id and
 * their grades.
 *
 */
typedef struct _student
{
    char first_name[50]; /**< the student's first name */
    char last_name[50];  /**< the student's last name */
    char id[11];         /**< the student's id */
    double *grades;      /**< the student's grades */
    int num_grades;      /**< the number of grades on record for the student*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student *generate_random_student(int grades);
