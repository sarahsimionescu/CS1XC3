/**
 * @file course.c
 * @author Sarah Simionescu
 * @date 04/02/2022
 * @brief Course library for managing and analyzing courses including their name, code and students.
 *        Includes course library function definitions.
 *
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * Enrolls a given student in a given course
 *
 * @param course a pointer to a course's details including a dynamic array of enrolled students (as defined in course.h)
 * @param student a pointer to a student's record (as defined in student.h)
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++; // increases the number of total students enrolled in the course by 1
  if (course->total_students == 1)
  {
    course->students = calloc(1, sizeof(Student)); // if the student list is empty, allocate space to enroll the student
  }
  else
  {
    course->students =
        realloc(course->students, course->total_students * sizeof(Student)); // otherwise, reallocate the appropriate amount of space in the existing list to add the new student
  }
  course->students[course->total_students - 1] = *student; // adds the given student to the list of enrolled students
}

/**
 * Prints a course's details including the course name, code, number of
 * students and list of students along with thier respective infromation (full name, id, grades and average)
 *
 * @param course a pointer to a course's details including a dynamic array of enrolled students (as defined in course.h)
 * @return nothing
 */
void print_course(Course *course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++)
    print_student(&course->students[i]);
}

/**
 * Finds and returns the student in the given course with the highest grade.
 *
 * @param course a pointer to a course's details including a dynamic array of enrolled students (as defined in course.h)
 * @return a pointer to the record for the student with the highest average in the course
 */
Student *top_student(Course *course)
{
  if (course->total_students == 0) // if there are no students in the course, return NULL
    return NULL;

  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
  // cycle through each student and keep track of the students who by far, has the highest average
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average)
    {
      max_average = student_average;
      student = &course->students[i];
    }
  }
  // after cycling through all the students in course, return the student with the highest average
  return student;
}

/**
 * Finds and returns a list of all the students in the course with a passing average of at least 50%.
 *
 * @param course a pointer to a course's details including a dynamic array of enrolled students (as defined in course.h)
 * @param total_passing a pointer to an int for the total number of passing students which will be updated accordingly by the function
 * @return a dynamic array of all the students with a passing average of at least 50%
 */
Student *passing(Course *course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;

  // cycles through each student in the course and counts the number of students with a passing average of at least 50%
  for (int i = 0; i < course->total_students; i++)
    if (average(&course->students[i]) >= 50)
      count++;

  passing = calloc(count, sizeof(Student));

  int j = 0;
  // filles a dynamic array with the records for the specific students with a passing average of at least 50%
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++;
    }
  }
  // sets total_passing to the total number of students with a passing average of at least 50%
  *total_passing = count;

  return passing; // returns the list of students
}