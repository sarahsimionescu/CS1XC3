var searchData=
[
  ['top_5fstudent',['top_student',['../course_8c.html#ae0130f7ef7b879c9a790ee27a5ce21b7',1,'top_student(Course *course):&#160;course.c'],['../course_8h.html#ae0130f7ef7b879c9a790ee27a5ce21b7',1,'top_student(Course *course):&#160;course.c']]],
  ['total_5fstudents',['total_students',['../struct__course.html#afd5e161f7cf358c13cc8aa868b462006',1,'_course']]]
];
